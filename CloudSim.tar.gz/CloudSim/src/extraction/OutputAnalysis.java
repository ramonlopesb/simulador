package extraction;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import com.google.common.io.Files;

public class OutputAnalysis {
	
	public static void main(String[] args) throws IOException {
		List<String> list = Files.readLines(new File("Initiation_Log.txt"), Charset.defaultCharset());
		List<String> required = new ArrayList<String>();
		List<String> answered = new ArrayList<String>();
		for (String line: list) {
			if (line.contains("requisitado")) {
				required.add(line);
			} else {
				answered.add(line);
			}
		}
		System.out.println(required.size());
		System.out.println(answered.size());
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File("time_to_answer.txt")));
		writer.append("request,start,duration,origin,answered");
		writer.append("\n");
		for (String line: required) {
			String[] split = line.split("--");
			String request = split[1].trim();
			String requestID = request.split(",")[0].split(":")[1].trim();
			String startTime = request.split(",")[1].split(":")[1].trim();
			String duration = request.split(",")[2].split(":")[1].trim();
			String cloud = request.split(",")[3].split(":")[1].trim();
			String answer = "-";
			boolean found = false;
			for (String a: answered) {
				if (a.contains(request)) {
					found = true;
					answer = a.split("atendido pela nuvem")[1].trim().replace(".", "");
					break;
				} 
			}
			if (found) {
				writer.append(requestID + "," + startTime + "," + duration + "," + cloud + "," + answer);
			} else {
				writer.append(requestID + "," + startTime + ",-" + "," + cloud + "," + answer);
			}
			writer.append("\n");
		}
		writer.flush();
		writer.close();
	}

}
