package extraction;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Test {
	
	public static void main(String[] args) {
		String[] a = new String[1000000];
		Map<String, String> b = new HashMap<String, String>();
		for (int i = 0; i < 1000000; i++) {
			a[i] = "";
			b.put(String.valueOf(i), "");
		}
		
		long t = System.nanoTime();
		String j = a[100000];
		long ts = System.nanoTime();
		
		System.out.println(ts - t);
		
		t = System.nanoTime();
		j = b.get(100000);
		ts = System.nanoTime();
		
		System.out.println(ts - t);
		
		//array to store N random integers (0 - N-1)
        int[] nums = new int[15];

        // initialize each value at index i to the value i 
        for (int i = 0; i < nums.length; ++i)
        {
            nums[i] = i;
        }

        Random randomGenerator = new Random();
        int randomIndex; // the randomly selected index each time through the loop
        int randomValue; // the value at nums[randomIndex] each time through the loop

        // randomize order of values
        for(int i = 0; i < nums.length; ++i)
        {
             // select a random index
             randomIndex = randomGenerator.nextInt(nums.length - 2);

             // swap values
             randomValue = nums[randomIndex];
             nums[randomIndex] = nums[i];
             nums[i] = randomValue;
        }
        
        for (int i = 0; i < nums.length; ++i)
        {
            System.out.println(1+nums[i]);
        }
	}

}
