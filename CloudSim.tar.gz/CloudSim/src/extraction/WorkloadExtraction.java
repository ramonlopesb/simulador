package extraction;

import info.RequestEvent;
import info.SystemProperties;
import info.Workload;
import info.cloud.Cloud;
import info.cloud.CloudImageRepository;
import info.cloud.Resources;
import info.image.Image;
import info.image.WebImageRepository;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.SortedSet;
import java.util.TreeSet;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

import com.google.common.io.Files;

public class WorkloadExtraction {

	public static void main(String[] args) throws IOException, JDOMException {
		SystemProperties.getInstance().load(new FileInputStream(new File("Properties.properties")));
		File dir = new File("/home/ramon/workspace/CloudSim");

		File[] files = new File[6];

		int pos = 0;
		for (int i = 0; i < dir.listFiles().length; i++) {
			if (dir.listFiles()[i].getName().startsWith("workload_clust")) {
				files[pos++] = dir.listFiles()[i];
			}
		}

		List<String> output = new ArrayList<String>();
		for (File f : files) {
			List<String> lines = Files.readLines(f, Charset.defaultCharset());
			for (String line : lines) {
				if (!line.startsWith("Submit")) {
					output.add(line);
				}
			}
		}

		List<String> output2 = new ArrayList<String>();
		for (String o : output) {
			int k = 30;
			int i = 0;
			while (i < 5) {
				for (int j = k + 1; j <= k + 15; j++) {
					if (o.contains("P" + j)) {
						o = o.replace("P" + j, "P" + (j - k));
					}
				}
				k += 15;
				i++;
			}
			output2.add(o);
		}

		output = new ArrayList<String>();

		for (String o : output2) {
			int k = 300;
			int i = 0;
			while (i < 5) {
				for (int j = k + 1; j <= k + 15; j++) {
					if (o.contains("U" + j)) {
						o = o.replace("U" + j, "U" + (j - k));
					}
				}
				k += 300;
				i++;
			}
			output.add(o);
		}

		List<WorkloadInfo> infos = new ArrayList<WorkloadInfo>();
		for (String o : output) {
			String[] split = o.split(" ");
			if (Integer.parseInt(split[1]) > 200) {
				infos.add(new WorkloadInfo(Integer.valueOf(split[2]), Integer.valueOf(split[4].replace("P", "")), Long
						.valueOf(split[0]), Long.valueOf(split[1]), Integer.valueOf(split[3].replace("U", ""))));
			}
		}

		Map<Long, Map<Integer, Map<Integer, List<WorkloadInfo>>>> byTime = new HashMap<Long, Map<Integer, Map<Integer, List<WorkloadInfo>>>>();
		int i = 1;

		for (WorkloadInfo w : infos) {
			// 1 é a posicao do tempo de inicio do pedido, 2 é o tempo de
			// execucao, 3 é a nuvem
			if (byTime.get(w.getStartTime()) == null) {
				byTime.put(w.getStartTime(), new HashMap<Integer, Map<Integer, List<WorkloadInfo>>>());
			}

			if (byTime.get(w.getStartTime()).get(w.getCloudID()) == null) {
				byTime.get(w.getStartTime()).put(w.getCloudID(), new HashMap<Integer, List<WorkloadInfo>>());
			}

			if (byTime.get(w.getStartTime()).get(w.getCloudID()).get(w.getUserID()) == null) {
				byTime.get(w.getStartTime()).get(w.getCloudID()).put(w.getUserID(), new ArrayList<WorkloadInfo>());
			}

			byTime.get(w.getStartTime()).get(w.getCloudID()).get(w.getUserID()).add(w);

		}
		
		SortedSet<Long> sortedSet = new TreeSet<Long>(byTime.keySet());
		List<WorkloadInfo> l = new ArrayList<WorkloadInfo>();
		int count = 1;
		for (Long time : sortedSet) {
			Map<Integer, Map<Integer, List<WorkloadInfo>>> byCloud = byTime.get(time);
			for (Integer cloud : byCloud.keySet()) {
				Map<Integer, List<WorkloadInfo>> byUser = byCloud.get(cloud);
				for (Integer user : byUser.keySet()) {
					Collections.sort(byUser.get(user), new WorkloadInfoComparator());
					for (WorkloadInfo data : byUser.get(user)) {
						data.setRequestID(i);
						data.setWorkloadID(count++);
						l.add(data);
					}
					i++;
				}
			}
		}

		SAXBuilder sb = new SAXBuilder();
		Document docImages = sb.build(new File("images.xml"));
		Document docVOs = sb.build(new File("VO.xml"));
		Document docVOsImages = sb.build(new File("VOs_Images.xml"));

		createWorkload(
				readVOs(docVOs.getRootElement(), docVOsImages.getRootElement(), readImages(docImages.getRootElement())),
				l);
	}

	private static Image getImageByID(int imageId, Map<String, Image> images) {
		for (String name : images.keySet()) {
			if (images.get(name).getID() == imageId) {
				return images.get(name);
			}
		}
		return null;
	}

	private static List<Image> getCloudImages(Element docVOsImages, int id, Map<String, Image> images) {
		List<Image> voImages = new ArrayList<Image>();
		List<Element> list = docVOsImages.getChildren("site");
		for (Element s : list) {
			if (Integer.valueOf(s.getAttributeValue("id")) == id) {
				List<Element> imgs = s.getChildren("image");
				for (Element img : imgs) {
					int imageId = Integer.valueOf(img.getText());
					voImages.add(getImageByID(imageId, images));
				}
			}
		}
		return voImages;
	}

	private static Cloud[] readVOs(Element vos, Element docVOsImages, Map<String, Image> images) {
		Cloud[] clouds = new Cloud[16];
		List<Element> vosList = vos.getChildren("site");
		for (Element vo : vosList) {
			int cloudID = Integer.parseInt(vo.getAttributeValue("id"));
			String cloudName = vo.getAttributeValue("name");
			Resources resources = new Resources(Integer.parseInt(SystemProperties.getInstance().getPropertyValue(
					"cloud.vcpu")), Integer.parseInt(SystemProperties.getInstance().getPropertyValue("cloud.ram")),
					Double.parseDouble(SystemProperties.getInstance().getPropertyValue("cloud.disk")),
					Integer.parseInt(SystemProperties.getInstance().getPropertyValue("cloud.bandwidth")));
			CloudImageRepository repository = new CloudImageRepository(cloudID, Double.valueOf(SystemProperties
					.getInstance().getPropertyValue("repository.capacity")));
			for (Image img : getCloudImages(docVOsImages, cloudID, images)) {
				if (img != null) {
					repository.addImage(cloudID, img, 0L);
				}
			}
			Cloud cloud = new Cloud(cloudID, cloudName, resources, repository);
			clouds[cloudID] = cloud;
		}
		WebImageRepository.getInstance().setImages(new ArrayList<Image>(images.values()));
		return clouds;
	}

	private static Map<String, Image> readImages(Element doc) {
		Map<String, Image> images = new HashMap<String, Image>();
		List<Element> nodeImages = doc.getChildren("image");
		for (Element e : nodeImages) {
			Image image = new Image(e.getAttributeValue("name"), e.getAttributeValue("os"),
					e.getAttributeValue("os_version"), Integer.parseInt(e.getAttributeValue("id")), Integer.parseInt(e
							.getAttributeValue("size")));
			images.put(e.getAttributeValue("name"), image);
		}
		return images;
	}

	private static void createWorkload(Cloud[] clouds, List<WorkloadInfo> list) throws IOException {
		Map<Long, Map<Integer, Map<Integer, List<RequestEvent>>>> byTime = new HashMap<Long, Map<Integer, Map<Integer, List<RequestEvent>>>>();
		Map<Long, List<RequestEvent>> workloads = new HashMap<Long, List<RequestEvent>>();
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File("result_workload.txt")));
		for (WorkloadInfo l : list) {
			// 1 é a posicao do tempo de inicio do pedido, 2 é o tempo de
			// execucao, 3 é a nuvem
			if (byTime.get(l.getStartTime()) == null) {
				byTime.put(l.getStartTime(), new HashMap<Integer, Map<Integer, List<RequestEvent>>>());
			}

			if (byTime.get(l.getStartTime()).get(l.getCloudID()) == null) {
				byTime.get(l.getStartTime()).put(l.getCloudID(), new HashMap<Integer, List<RequestEvent>>());
			}

			if (byTime.get(l.getStartTime()).get(l.getCloudID()).get(l.getUserID()) == null) {
				byTime.get(l.getStartTime()).get(l.getCloudID()).put(l.getUserID(), new ArrayList<RequestEvent>());
			}

			byTime.get(l.getStartTime())
					.get(l.getCloudID())
					.get(l.getUserID())
					.add(new RequestEvent(l.getRequestID(), new Workload(l.getWorkloadID(), l.getCloudID(), l
							.getStartTime(), l.getDurationTime(), Integer.valueOf(SystemProperties.getInstance()
							.getPropertyValue("image.vcpu")), Integer.valueOf(SystemProperties.getInstance()
							.getPropertyValue("image.ram")), Integer.valueOf(SystemProperties.getInstance()
							.getPropertyValue("image.disk")))));

		}

		// seta as imagens por jobs (composição de tarefas)
		SortedSet<Long> sortedSet = new TreeSet<Long>(byTime.keySet());
		for (Long time : sortedSet) {
			if (workloads.get(time) == null) {
				workloads.put(time, new ArrayList<RequestEvent>());
			}
			Map<Integer, Map<Integer, List<RequestEvent>>> byCloud = byTime.get(time);
			for (Integer cloudID : byCloud.keySet()) {
				Cloud cloud = clouds[cloudID];
				Map<Integer, List<RequestEvent>> byUser = byCloud.get(cloudID);
				for (Integer userID : byUser.keySet()) {
					int randomImageID = new Random().nextInt(cloud.getCacheSystem().getImages().length);
					for (RequestEvent r : byUser.get(userID)) {
						writer.append(r.getRequestID() + " " + r.getWorkloadID() + " " + r.getStartTime() + " "
								+ r.getDurationTime() + " " + r.getFromCloudID() + " "
								+ cloud.getCacheSystem().getImages()[randomImageID]);
						writer.append("\n");
					}
				}
			}
		}
		writer.flush();
		writer.close();
	}

}

class WorkloadInfo {

	private int cloudID;
	private long startTime;
	private long durationTime;
	private int requestID;
	private int userID;
	private int workloadID;

	public WorkloadInfo(int id, int cloudID, long start, long duration, int userID) {
		this.requestID = id;
		this.cloudID = cloudID;
		this.startTime = start;
		this.durationTime = duration;
		this.userID = userID;
	}

	public void setWorkloadID(int i) {
		this.workloadID = i;
	}

	public void setRequestID(int i) {
		this.requestID = i;
	}

	public int getCloudID() {
		return cloudID;
	}

	public long getStartTime() {
		return startTime;
	}

	public long getDurationTime() {
		return durationTime;
	}

	public int getRequestID() {
		return requestID;
	}

	public int getUserID() {
		return userID;
	}

	public int getWorkloadID() {
		return workloadID;
	}

}

class WorkloadInfoComparator implements Comparator<WorkloadInfo> {

	@Override
	public int compare(WorkloadInfo o1, WorkloadInfo o2) {
		if (o1.getStartTime() < o2.getStartTime()) {
			return -1;
		}
		if (o1.getStartTime() > o2.getStartTime()) {
			return 1;
		}
		return 0;
	}

}
