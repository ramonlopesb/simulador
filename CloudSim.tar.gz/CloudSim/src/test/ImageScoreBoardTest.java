package test;

import static org.junit.Assert.assertEquals;
import info.cloud.ImageScoreBoard;

import org.junit.Before;
import org.junit.Test;

public class ImageScoreBoardTest {
	
	private ImageScoreBoard board;
	
	@Before
	public void setUp() {
		board = new ImageScoreBoard();
		board.scoreByImage(1, 500L);
		board.scoreByImage(2, 200L);
		board.scoreByImage(3, 300L);
		board.scoreByImage(4, 400L);
		board.scoreByImage(5, 100L);
		board.scoreByImage(5, 150L);
	}
	
	@Test
	public void getCandidateTest() {
		assertEquals(2, board.getCandidate(new Integer[] {new Integer(1), new Integer(2)}));
		
		assertEquals(2, board.getCandidate(new Integer[] {new Integer(2), new Integer(3)}));
		
		assertEquals(2, board.getCandidate(new Integer[] {new Integer(2), new Integer(5)}));
		
		assertEquals(3, board.getCandidate(new Integer[] {new Integer(1), new Integer(3)}));
	}
	
}
