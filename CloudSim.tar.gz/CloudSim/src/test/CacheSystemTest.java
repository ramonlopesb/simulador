package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import info.SystemProperties;
import info.cloud.CacheSystem;
import info.cloud.CloudImageRepository;
import info.cloud.CloudScoreBoard;
import info.filesystem.NoDeduplicationFileSystem;
import info.image.Image;
import info.image.ImagesSize;
import info.image.WebImageRepository;
import info.replacement.LeastProfitable;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CacheSystemTest {
	
	CacheSystem cache;
	CloudImageRepository rep;
	Image image1;
	Image image2;
	Image image3;
	Image image4;
	Image image10;
	Image image11;
	CloudScoreBoard board;
	
	@Before
	public void setUp() throws FileNotFoundException, IOException {
		SystemProperties.getInstance().load(
				new FileInputStream(new File("/home/ramon/workspace/CloudSim/Properties.properties")));
		rep = new CloudImageRepository(1, 102400.0);
		ImagesSize.getInstance().setStrategy(new NoDeduplicationFileSystem());
		image1 = new Image("", "", "", 100, 25600);
		image2 = new Image("", "", "", 200, 25600);
		image3 = new Image("", "", "", 300, 25600);
		image4 = new Image("", "", "", 400, 25600);
		image10 = new Image("", "", "", 1000, 25600);
		image11 = new Image("", "", "", 1100, 25600);

		WebImageRepository.getInstance().setImages(new ArrayList<Image>() {
			{
				add(image1);
				add(image2);
				add(image3);
				add(image4);
				add(image10);
				add(image11);
			}
		});
		
		cache = new CacheSystem(1, rep);
		cache.setStrategy(new LeastProfitable());
		
		cache.add(1, image1, 1L);
		cache.add(1, image2, 2L);
		cache.add(2, image3, 3L);
		cache.add(3, image4, 4L);
		
		cache.scoreByImage(1, 100, 400);
		cache.scoreByImage(2, 100, 400);
		cache.scoreByImage(3, 100, 200);
		cache.scoreByImage(1, 200, 450);
		cache.scoreByImage(2, 200, 100);
		cache.scoreByImage(3, 300, 119);
		cache.scoreByImage(4, 400, 100);
		cache.scoreByImage(1, 400, 800);
		
		board = CloudScoreBoard.getInstance();
		board.scoreByCloud(1, 2, 400);
		board.scoreByCloud(2, 1, 0);
		
		board.scoreByCloud(1, 2, 100);
		board.scoreByCloud(2, 1, 0);
		
		board.scoreByCloud(1, 3, 200);
		board.scoreByCloud(3, 1, 0);
		
		board.scoreByCloud(1, 3, 119);
		board.scoreByCloud(3, 1, 0);
	}
	
	@After
	public void tearDown() {
		WebImageRepository.getInstance().resetInstance();
		board.resetInstance();
	}
	
	@Test
	public void getImageTest() {
		assertEquals(4, cache.getImages().length);
		for (Integer id: cache.getImages()) {
			assertTrue("100 200 300 400".contains(id.toString()));
		}
	}
	
	@Test
	public void getScoreTest() {
		assertEquals(1000, cache.getScoreByImage(100));
		
		assertEquals(550, cache.getScoreByImage(200));
		
		assertEquals(119, cache.getScoreByImage(300));
		
		assertEquals(900, cache.getScoreByImage(400));
	}
	
	@Test
	public void addWithContetionTest() {
		// imagens antes da inserção da imagem 10
		// contenção de recursos
		// a imagem que dá menos lucro será removida da nuvem que
		// menos contribuiu com esta nuvem
		// imagem 1 = 1000 pontos - pertence a nuvem 1 - local
		// imagem 2 = 550 pontos - pertence a nuvem 1 - local
		// imagem 3 = 119 pontos - pertence a nuvem 2 - remoto
		// imagem 4 = 900 pontos - pertence a nuvem 3 - remoto
		// nem a nuvem 2 e 3 contribuiram com a nuvem 1, então ambas possuem cota 0
		// a nuvem escolhida é a 3 por ser a primeira a ser analisada
		List<Integer> ids = new ArrayList<Integer>() { {add(100); add(200); add(300); add(400);} };
		for (int id: cache.getImages()) {
			assertTrue(ids.contains(id));
		}
		cache.add(1, image10, 10L);
		assertEquals(4, cache.getImages().length);
		// como a nuvem 3 possuia apenas a imagem 4, ela é a removida
		// logo, as imagens inseridas são 1,2,3,10
		ids = new ArrayList<Integer>() { {add(100); add(200); add(300); add(1000);} };
		for (int id: cache.getImages()) {
			assertTrue(ids.contains(id));
		}
		
		// vamos inserir agora uma imagem para a nuvem 3, que não possui cota
		cache.add(3, image11, 10L);
		// essa imagem não será inserida
		for (int id: cache.getImages()) {
			assertTrue(ids.contains(id));
		}
		
		// mas digamos que a nuvem 3 pontuou para a nuvem 1
		board.scoreByCloud(3, 1, 600);
		// a nuvem 2 continua a não pontuar. a nuvem 3 pode usar 100% do espaço 
		// reservado da nuvem 1
		// inserindo uma nova imagem, a imagem da nuvem 2 será excluída
		// vamos inserir agora uma imagem para a nuvem 3, que não possui cota
		cache.add(3, image11, 10L);
		ids = new ArrayList<Integer>() { {add(100); add(200); add(1000); add(1100);} };
		for (int id: cache.getImages()) {
			assertTrue(ids.contains(id));
		}
	}

}
