package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import info.SystemProperties;
import info.cloud.CloudImageRepository;
import info.filesystem.NoDeduplicationFileSystem;
import info.image.Image;
import info.image.ImagesSize;
import info.image.WebImageRepository;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

public class CloudImageRepositoryTest {

	CloudImageRepository rep;
	Image image1;
	Image image2;
	Image image3;
	Image image4;
	private Image image10;
	private Image image11;

	@Before
	public void setUp() throws FileNotFoundException, IOException {
		SystemProperties.getInstance().load(
				new FileInputStream(new File("/home/ramon/workspace/CloudSim/Properties.properties")));
		rep = new CloudImageRepository(10, 102400.0);
		ImagesSize.getInstance().setStrategy(new NoDeduplicationFileSystem());
		image1 = new Image("", "", "", 1, 25600);
		image2 = new Image("", "", "", 2, 25600);
		image3 = new Image("", "", "", 3, 25600);
		image4 = new Image("", "", "", 4, 25600);
		image10 = new Image("", "", "", 10, 25600);
		image11 = new Image("", "", "", 11, 25600);

		rep.addImage(10, image1, 1L);
		rep.addImage(10, image2, 2L);
		rep.addImage(12, image3, 3L);
		rep.addImage(13, image4, 4L);
		
		WebImageRepository.getInstance().setImages(new ArrayList<Image>() {
			{
				add(image1);
				add(image2);
				add(image3);
				add(image4);
				add(image10);
				add(image11);
			}
		});
	}

	@Test
	public void addImageTest() {
		// cloud 1
		assertEquals(2, rep.getImagesIDs(10).size());
		assertEquals(new Integer(1), rep.getImagesIDs(10).get(0));
		assertEquals(new Integer(2), rep.getImagesIDs(10).get(1));

		// cloud 2
		assertEquals(1, rep.getImagesIDs(12).size());
		assertEquals(new Integer(3), rep.getImagesIDs(12).get(0));

		// cloud 3
		assertEquals(1, rep.getImagesIDs(13).size());
		assertEquals(new Integer(4), rep.getImagesIDs(13).get(0));
	}

	@Test
	public void getRemoteIDsTest() {
		assertEquals(2, rep.getRemoteImagesIDs().size());
		for (Integer id: rep.getRemoteImagesIDs()) {
			assertTrue("[3 4]".contains(id.toString()));
		}
	}
	
	@Test 
	public void getLocalIDsTest() {
		assertEquals(2, rep.getLocalImagesIDs().size());
	}
	
	@Test
	public void getAvailableSpace() {
		assertEquals(0.0, rep.getAvailableSpace(), 0.0);
	}
	
	@Test
	public void verifyContention() {
		rep.verifyContention(new int[] {10, 11});
		Assert.assertTrue(rep.isOnContention());
	}

	@Test
	public void getRemoteSpaceTest() {
		assertEquals(51200, rep.getRemoteSpace(), 0.0);
	}
	
	@Test
	public void removeRemote() {
		for (Integer id: rep.getRemoteImagesIDs()) {
			assertTrue("[3, 4]".contains(id.toString())); 
		}
		assertEquals(51200, rep.getRemoteSpace(), 0.0);
		rep.removeRemote();
		assertEquals("[]", rep.getRemoteImagesIDs().toString());
		assertEquals(0.0, rep.getRemoteSpace(), 0.0);
		assertEquals(51200, rep.getAvailableSpace(), 0.0);
	}
	
	@Test
	public void getUsedSpaceTest() {
		assertEquals(51200, rep.getUsedSpace(10), 0.0);
		assertEquals(25600, rep.getUsedSpace(12), 0.0);
		assertEquals(25600, rep.getUsedSpace(13), 0.0);
	}
	
	@Test
	public void removeImagesTest() {
		rep.removeImage(1);
		assertEquals(3, rep.getImagesIDs().length);
		assertEquals(25600, rep.getUsedSpace(10), 0.0);
		
		rep.removeImage(2);
		assertEquals(2, rep.getImagesIDs().length);
		assertEquals(0, rep.getUsedSpace(10), 0.0);

		rep.removeImage(3);
		assertEquals(1, rep.getImagesIDs().length);
		assertEquals(0, rep.getUsedSpace(12), 0.0);

		rep.removeImage(4);
		assertEquals(0, rep.getImagesIDs().length);
		assertEquals(0, rep.getUsedSpace(13), 0.0);
	}

}

