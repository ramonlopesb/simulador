package test;

import static org.junit.Assert.assertEquals;
import info.cloud.CloudScoreBoard;

import org.junit.Before;
import org.junit.Test;

public class CloudScoreBoardTest {
	
	private CloudScoreBoard board;
	
	@Before
	public void setUp() {
		board = CloudScoreBoard.getInstance();
		
		board.scoreByCloud(1, 2, 200L);
		board.scoreByCloud(1, 3, 100L);
		
		board.scoreByCloud(2, 1, 50L);
		board.scoreByCloud(2, 3, 50L);
		
		board.scoreByCloud(3, 1, 0L);
		board.scoreByCloud(3, 2, 20L);
	}
	
	@Test
	public void getScoreTest() {
		assertEquals(0L, board.getAccounting(1, 2));
		assertEquals(150L, board.getAccounting(2, 1));
		assertEquals(0L, board.getAccounting(1, 3));
		assertEquals(100L, board.getAccounting(3, 1));
		assertEquals(0L, board.getAccounting(2, 3));
		assertEquals(30L, board.getAccounting(3, 2));
		
		assertEquals(0, board.calculateQuote(1, 2, 204800), 0.0);
		assertEquals(0, board.calculateQuote(1, 3, 204800), 0.0);
		assertEquals(204800, board.calculateQuote(2, 1, 204800), 0.0);
		assertEquals(0, board.calculateQuote(2, 3, 204800), 0.0);
		assertEquals(157538.46, board.calculateQuote(3, 1, 204800), 0.2);
		assertEquals(47261.54, board.calculateQuote(3, 2, 204800), 0.2);
	}
	
}
