package info.image;

public class Image implements Comparable<Image> {

	public static enum IMAGE_STATUS {

		/** Imagem pronta para ser utilizada. **/
		READY,

		/** Imagem baixando. **/
		DOWNLOADING;

	}

	private String name;
	private String os;
	private String version;
	private int id;
	private int size;
	private IMAGE_STATUS status;

	public Image(String name, String os, String version, int id, int size) {
		this.name = name;
		this.os = os;
		this.version = version;
		this.id = id;
		this.size = size;
		this.status = IMAGE_STATUS.READY;
	}

	public Image(Image image) {
		this(image.getName(), image.getOS(), image.getVersion(), image.getID(), image.getSize());
	}

	public void setStatus(IMAGE_STATUS status) {
		this.status = status;
	}

	public boolean isReady() {
		return this.status == IMAGE_STATUS.READY;
	}

	public String getName() {
		return this.name;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Image)) {
			return false;
		}
		Image img = (Image) obj;
		if (!getOS().equals(img.getOS())) {
			return false;
		}
		if (!getVersion().equals(img.getVersion())) {
			return false;
		}
		return true;
	}

	private String getVersion() {
		return this.version;
	}

	private String getOS() {
		return this.os;
	}

	public int getID() {
		return this.id;
	}

	@Override
	public int compareTo(Image o) {
		return getID() == o.getID() ? 0 : (getID() > o.getID() ? 1 : -1);
	}

	public int getSize() {
		return this.size;
	}

}
