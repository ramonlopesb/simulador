package info.filesystem;

import info.image.WebImageRepository;

public class NoDeduplicationFileSystem implements FileSystemIF {

	@Override
	public double getSizeOf(int[] storedIDs, int... toStore) {
		return getSizeOf(storedIDs) + getSizeOf(toStore);
	}

	@Override
	public double getSizeOf(int[] storedIDs) {
		double size = 0.0;
		if (storedIDs.length != 0) {
			for (int i = 0; i < storedIDs.length; i++) {
				if (storedIDs[i] != 0) {
					size += WebImageRepository.getInstance().getImage(storedIDs[i]).getSize();
				}
			}
		}
		return size;
	}

}
