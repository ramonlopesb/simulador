package info.cloud;

import info.SystemProperties;
import info.filesystem.NoDeduplicationFileSystem;
import info.image.Image;
import info.image.Image.IMAGE_STATUS;
import info.image.ImagesSize;

import java.util.ArrayList;
import java.util.List;

import com.google.common.primitives.Ints;

public class CloudImageRepository {

	private int ownerID;
	private double capacity;
	private Image[] images;
	private boolean onContention;
	// mapa dos donos das imagens <image, cloud>
	private int[][] imagesCloudIDs;
	private Long[] imagesInsertionTimes;

	public CloudImageRepository(int id, double capacity) {
		this.ownerID = id;
		this.capacity = capacity;
		this.images = new Image[Integer.valueOf(SystemProperties.getInstance().getPropertyValue("images.size")) + 1];
		this.imagesCloudIDs = new int[Integer.valueOf(SystemProperties.getInstance().getPropertyValue("images.size")) + 1][Integer
				.valueOf(SystemProperties.getInstance().getPropertyValue("clouds.size")) + 1];
		this.imagesInsertionTimes = new Long[Integer.valueOf(SystemProperties.getInstance().getPropertyValue(
				"images.size")) + 1];
	}

	public void addImage(int cloudID, Image img, Long time) {
		if (this.images[img.getID()] == null) {
			this.images[img.getID()] = img;
			this.imagesCloudIDs[img.getID()][cloudID] = cloudID;
			this.imagesInsertionTimes[img.getID()] = time;
		}
	}

	public double getRemoteSpace() {
		// verificar como fazer com dedup
		return ImagesSize.getInstance().getSizeOf(Ints.toArray(getRemoteImagesIDs()));
	}

	public List<Integer> getRemoteImagesIDs() {
		List<Integer> remoteIDs = new ArrayList<Integer>();
		for (int i = 1; i < imagesCloudIDs.length; i++) {
			for (int j = 1; j < imagesCloudIDs[i].length; j++) {
				if (imagesCloudIDs[i][j] != 0L && imagesCloudIDs[i][j] != ownerID
						&& (this.images[i] != null && this.images[i].isReady())) {
					remoteIDs.add(i);
				}
			}
		}
		return remoteIDs;
	}

	public String remoteImageIDsToString() {
		String result = "[";
		List<Integer> remoteIDs = getRemoteImagesIDs();
		for (Integer id : remoteIDs) {
			result += id + " (" + getImageOwnerID(id) + ") ";
		}
		result = result.trim();
		result += "]";
		return result;
	}

	public List<Integer> getLocalImagesIDs() {
		List<Integer> localIDs = new ArrayList<Integer>();
		for (int i = 1; i < imagesCloudIDs.length; i++) {
			for (int j = 1; j < imagesCloudIDs[i].length; j++) {
				if (imagesCloudIDs[i][j] != 0 && imagesCloudIDs[i][j] == ownerID
						&& (this.images[i] != null && this.images[i].isReady())) {
					localIDs.add(i);
				}
			}
		}
		return localIDs;
	}

	public double getAvailableSpace() {
		return this.capacity - ImagesSize.getInstance().getSizeOf(getImagesIDs());
	}

	public void verifyContention(int... id) {
		// TODO
		double size = 0;
		if (ImagesSize.getInstance().getFileSystem() instanceof NoDeduplicationFileSystem) {
			size = ImagesSize.getInstance().getSizeOf(id);
		} else {
			size = ImagesSize.getInstance().getSizeOf(getImagesIDs(), id);
		}

		onContention = size > getAvailableSpace();
	}

	public boolean isOnContention() {
		return onContention;
	}

	public boolean removeImage(Image img) {
		if (img.isReady()) {
			this.images[img.getID()] = null;
			this.imagesInsertionTimes[img.getID()] = 0L;
			this.imagesCloudIDs[img.getID()][getImageOwnerID(img.getID())] = 0;
			return this.images[img.getID()] == null;
		} else {
			return false;
		}
	}

	public int[] getImagesIDs() {
		int pos = 0;
		for (Image img : images) {
			if (img != null && img.isReady()) {
				pos++;
			}
		}
		int[] ids = new int[pos];
		pos = 0;
		for (int i = 0; i < images.length; i++) {
			if (images[i] != null && images[i].isReady()) {
				ids[pos++] = images[i].getID();
			}
		}
		return ids;
	}

	public boolean contains(int imageID) {
		return this.images[imageID] != null;
	}

	public boolean contains(Image i) {
		return this.images[i.getID()] != null;
	}

	public double getTotalSpace() {
		return this.capacity;
	}

	public int getImageOwnerID(int imageID) {
		for (int i = 1; i < imagesCloudIDs[imageID].length; i++) {
			if (imagesCloudIDs[imageID][i] != 0) {
				return imagesCloudIDs[imageID][i];
			}
		}
		return 0;
	}

	public void setImageOwnerID(int newOwnerID, int imageID) {
		this.imagesCloudIDs[imageID][newOwnerID] = newOwnerID;
	}

	public void setImageInsertionTime(int imageID, Long time) {
		this.imagesInsertionTimes[imageID] = time;
	}

	public void removeRemote(ImageScoreBoard strategy) {
		for (Integer id : getRemoteImagesIDs()) {
			removeImage(id);
			strategy.removeImage(id);
		}
	}

	public void removeImage(int toRemove) {
		this.images[toRemove] = null;
		this.imagesInsertionTimes[toRemove] = 0L;
		this.imagesCloudIDs[toRemove][getImageOwnerID(toRemove)] = 0;
	}

	public double getUsedSpace(Integer cloudID) {
		double space = 0.0;
		for (int i = 1; i < this.imagesCloudIDs.length; i++) {
			if (this.imagesCloudIDs[i][cloudID] == cloudID & this.imagesCloudIDs[i][cloudID] != 0L) {
				space += ImagesSize.getInstance().getSizeOf(i);
			}
		}
		return space;
	}

	public List<Integer> getImagesIDs(int cloudID) {
		List<Integer> imagesIDs = new ArrayList<Integer>();
		for (int i = 1; i < this.imagesCloudIDs.length; i++) {
			if (this.imagesCloudIDs[i][cloudID] == cloudID & this.imagesCloudIDs[i][cloudID] != 0L
					&& (this.images[i] != null && this.images[i].isReady())) {
				imagesIDs.add(i);
			}
		}
		return imagesIDs;
	}

	public List<Integer> getRemoteCloudIDs() {
		List<Integer> remoteIDs = new ArrayList<Integer>();
		for (int i = 1; i < this.imagesCloudIDs.length; i++) {
			for (int j = 1; j < this.imagesCloudIDs[i].length; j++) {
				if (this.imagesCloudIDs[i][j] != ownerID && this.imagesCloudIDs[i][j] != 0L
						&& (this.images[i] != null && this.images[i].isReady())) {
					remoteIDs.add(j);
				}
			}
		}
		return remoteIDs;
	}

	public void removeRemote() {
		for (Integer id : getRemoteImagesIDs()) {
			removeImage(id);
		}
	}

	public void setImageStatus(Integer id, IMAGE_STATUS status) {
		this.images[id].setStatus(status);
	}

	public boolean isReady(int imageID) {
		return this.images[imageID].isReady();
	}

}
