package info.cloud;


public class ImageScoreBoard {
	
	private final int IMAGES_SIZE = 26;

	// from, image, score
	protected long[] byImage = new long[IMAGES_SIZE];
	
	public ImageScoreBoard() {
		for (int i = 0; i < IMAGES_SIZE; i++) {
			byImage[i] = -1L;
		}
	}

	public void scoreByImage(int imageID, long score) {
		if (byImage[imageID] == -1L) {
			byImage[imageID] = 0L;
		}
		byImage[imageID] = byImage[imageID] + score;
	}

	public long getScoreByImage(int imageID) {
		return byImage[imageID];
	}

	public void removeImage(Integer imageID) {
		byImage[imageID] = -1L;
	}

	public int getCandidate(Integer... ids) {
		long min = Long.MAX_VALUE;
		int toRemove = 0;
		// para as imagens da nuvem
		for (Integer id : ids) {
			long score = byImage[id.intValue()];
			if (score < min && score != -1L) {
				min = score;
				toRemove = id;
			}
		}
		return toRemove;
	}
	
}
