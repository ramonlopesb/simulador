package info.cloud;

import info.Controller;
import info.RequestEvent;
import info.image.Image;
import info.image.Image.IMAGE_STATUS;
import info.image.WebImageRepository;
import info.log.InitiationTimeLog;
import info.log.LogWritter;
import info.replacement.LeastProfitable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Cloud {

	private int id;
	private String name;
	private Resources resources;
	private CloudScoreBoard scoreBoard = CloudScoreBoard.getInstance();

	private Long time = 0L;

	// <id da imagem, vm>
	private Map<Integer, Map<Long, List<RequestEvent>>> imageVMs;

	// o cache system é responsável pelo repositório de imagens
	private CacheSystem cacheSystem;

	public Cloud(int id, String name, Resources resources, CloudImageRepository repository) {
		this.id = id;
		this.name = name;
		this.resources = resources;
		this.cacheSystem = new CacheSystem(id, repository);
		this.cacheSystem.setStrategy(new LeastProfitable());
		this.imageVMs = new HashMap<Integer, Map<Long, List<RequestEvent>>>();
	}

	public int getID() {
		return this.id;
	}

	public String getCloudName() {
		return this.name;
	}

	public CacheSystem getCacheSystem() {
		return cacheSystem;
	}

	public synchronized void answer(Object request) {
		if (request instanceof RequestEvent) {
			answerRequest((RequestEvent) request);
		} else if (request instanceof FinishedDownloadEvent) {
			FinishedDownloadEvent event = (FinishedDownloadEvent) request;
			time = event.getTime() < time ? time : event.getTime();
			this.cacheSystem.setImageStatus(event.getID(), IMAGE_STATUS.READY);
			LogWritter.getInstance().write(
					time + " -- " + "Nuvem " + this.id + ": Download da imagem " + event.getID() + " concluído. ");
		} else if (request instanceof ScoreEvent) {
			RequestEvent r = ((ScoreEvent) request).getRequest();
			time = r.getStartTime() < time ? time : r.getStartTime();
			score(r);
			completeRequest(r);
		}
	}

	private void answerRequest(RequestEvent r) {
		time = r.getStartTime() < time ? time : r.getStartTime();
		if (this.resources.canAnswerRequest(r)) {
			if (this.cacheSystem.contains(r.getImageID()) && this.cacheSystem.verifySituation(r.getImageID())) {
				// se a requisição ainda está pendente, atendê-la
				if (r.checkPending()) {
					resources.allocate(r.getVCPUs(), r.getRam(), r.getDiskSize());

					int imageOwnerID = this.cacheSystem.getImageOwnerID(r.getImageID());

					if (r.getFromCloudID() != imageOwnerID) {
						verifyAndSetOwner(r.getImageID(), imageOwnerID);
					}

					long endTime = r.getStartTime() + r.getDurationTime();

					LogWritter.getInstance().write(
							time + " -- " + "Nuvem: " + this.id + ": Iniciando a VM da imagem " + r.getImageID()
									+ " do pedido [" + r.toString() + "] para terminar em " + endTime + ".");

					addImageVM(r.getImageID(), endTime, r);

					this.cacheSystem.setImageUtilizationTime(r.getImageID(), time);
					Controller.getInstance().addRequestEvent(endTime, r.getFromCloudID(), new ScoreEvent(this.id, r));

					InitiationTimeLog.getInstance().write(
							time + " -- Pedido [" + r.toString() + "] atendido pela nuvem " + this.id + ". ");
				}
			} else {
				long downloadTime = r.getStartTime() + resources.timeToDownload(r.getImageID()) + 1;

				// adiciona a imagem porém ela só está disponível após o término
				Image toDownload = new Image(WebImageRepository.getInstance().getImage(r.getImageID()));
				toDownload.setStatus(IMAGE_STATUS.DOWNLOADING);
				this.cacheSystem.add(r.getFromCloudID(), toDownload, downloadTime);

				// agendar o pedido para após o tempo de download
				LogWritter.getInstance().write(
						time + " -- " + "Nuvem: " + this.id + ": Adiando o pedido [" + r.toString() + "] para o tempo "
								+ downloadTime + " por falta da imagem " + r.getImageID() + ".");

				// adiciona o evento de download da imagem
				Controller.getInstance().addRequestEvent(downloadTime, this.id,
						new FinishedDownloadEvent(r.getImageID(), this.id, downloadTime));

				// adiciona o evento de atender o pedido para o tempo
				// downloadtime
				RequestEvent e = new RequestEvent(r);
				e.setFromCloudID(this.id);
				e.setStartingTime(downloadTime);
				Controller.getInstance().addRequestEvent(downloadTime, this.id, e);
			}
		} else {
			LogWritter.getInstance().write(
					time + " -- " + "Nuvem: " + this.id + ": O pedido [" + r.toString()
							+ "] não foi atendido por falta de recursos.");
		}
	}

	private void addImageVM(int imageID, long endTime, RequestEvent r) {
		if (imageVMs.get(r.getImageID()) == null) {
			imageVMs.put(r.getImageID(), new HashMap<Long, List<RequestEvent>>());
		}
		if (imageVMs.get(r.getImageID()).get(endTime) == null) {
			imageVMs.get(r.getImageID()).put(endTime, new ArrayList<RequestEvent>());
		}
		imageVMs.get(r.getImageID()).get(endTime).add(r);
	}

	private void verifyAndSetOwner(int imageID, int cloudID) {
		if (imageVMs.get(imageID) != null) {
			boolean hasOneExecuting = false;
			for (Long vmEndTime : imageVMs.get(imageID).keySet()) {
				if (vmEndTime < time) {
					hasOneExecuting = true;
					break;
				}
			}
			// se não tem mais alguma VM em execução, adiciona um
			// novo dono
			if (!hasOneExecuting) {
				this.cacheSystem.setImageOwnerID(cloudID, imageID);
			}
		}
	}

	public void score(RequestEvent r) {
		time = r.getStartTime();
		if (r.getFromCloudID() != this.id) {
			long score = r.getDurationTime() * WebImageRepository.getInstance().getImage(r.getImageID()).getSize();
			LogWritter.getInstance().write(
					time + " -- " + "Nuvem: " + this.id + ": Pontuando a quantidade de " + score
							+ " por ter iniciado uma VM da imagem " + r.getImageID() + " à nuvem " + r.getFromCloudID()
							+ " referente ao pedido [" + r.toString() + "].");

			// pontua
			scoreBoard.scoreByCloud(this.id, r.getFromCloudID(), score);
			// pontua com 0 inverso para fazer com que fromCloud conheça quem o
			// favoreceu
			scoreBoard.scoreByCloud(r.getFromCloudID(), this.id, 0);
		}
		this.cacheSystem.scoreByImage(this.id, r.getImageID(), r.getDurationTime());
	}

	private void completeRequest(RequestEvent r) {
		this.resources.deallocate(r.getVCPUs(), r.getRam(), r.getDiskSize());
	}

}
