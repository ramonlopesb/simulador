package info.cloud;

import info.image.Image;
import info.image.Image.IMAGE_STATUS;

import java.util.List;

public class CacheSystem {

	private int ownerID;
	private CloudImageRepository repository;
	private ImageScoreBoard strategy;

	public CacheSystem(int ownerID, CloudImageRepository repository) {
		this.ownerID = ownerID;
		this.repository = repository;
	}

	public void setStrategy(ImageScoreBoard st) {
		this.strategy = st;
	}

	public void add(Integer cloudID, Image image, Long time) {
		if (this.repository.contains(image)) {
			return;
		}
		verifyContention(image.getID());
		if (this.repository.isOnContention()) {
			addWithContention(cloudID, image, time);
		} else {
			this.repository.addImage(cloudID, image, time);
		}
	}

	private void addWithContention(Integer cloudID, Image image, Long time) {
		// TODO quando tiver dedup, muda
		double imageSize = image.getSize();
		if (imageSize <= this.repository.getTotalSpace()) {
			if (this.repository.getAvailableSpace() < imageSize) {
				if (imageSize > this.repository.getAvailableSpace()) {
					if (this.ownerID == cloudID) {
						addLocalImage(cloudID, image, imageSize, time);
					} else {
						addRemoteImage(cloudID, image, imageSize, time);
					}
				} else {
					this.repository.addImage(cloudID, image, time);
				}
			} else {
				this.repository.addImage(cloudID, image, time);
			}
		}
	}

	/**
	 * Adiciona a imagem referente ao pedido de uma nuvem.
	 * 
	 * @param cloudID
	 * @param image
	 * @param imageSize
	 * @param time
	 */
	private void addRemoteImage(Integer cloudID, Image image, double imageSize, Long time) {
		// TODO Auto-generated method stub
		double quote = CloudScoreBoard.getInstance().calculateQuote(
				ownerID,
				cloudID,
				(this.repository.getAvailableSpace() + this.repository
						.getRemoteSpace()));
		if (imageSize <= quote + (this.repository.getAvailableSpace())) {
			int id = getOverQuotaLeastReputationID(cloudID); // id == 0 não tem
																// cota
																// excedente
			while (imageSize > (this.repository.getAvailableSpace() + this.repository
					.getUsedSpace(cloudID)) && id != 0) {
				removeImageWithCriteria(id);

				id = getOverQuotaLeastReputationID(cloudID);
			}

			if (imageSize > (this.repository.getAvailableSpace())) {
				while (imageSize > (this.repository.getAvailableSpace())) {
					removeImageWithCriteria(cloudID);
				}
			}

			this.repository.addImage(cloudID, image, time);
		}
	}

	private void removeImageWithCriteria(int cloudID) {
		List<Integer> ids = this.repository.getImagesIDs(cloudID);
		int candidate = this.strategy.getCandidate(ids.toArray(new Integer[ids.size()]));
		this.repository.removeImage(candidate);
		this.strategy.removeImage(candidate);
	}

	/**
	 * O id da nuvem que tem cota excedente.
	 * 
	 * @param cloudID
	 *            o id excludente
	 * @return o id da nuvem com cota excedente
	 */
	private int getOverQuotaLeastReputationID(Integer cloudID) {
		Integer selectedID = 0;
		double temp = Double.MAX_VALUE;
		for (Integer id : this.repository.getRemoteCloudIDs()) {
			if (id != cloudID) {
				double quote = CloudScoreBoard.getInstance().calculateQuote(cloudID, id,
						this.repository.getAvailableSpace() + this.repository.getRemoteSpace());
				if (quote < temp && quote < this.repository.getUsedSpace(id)) {
					temp = quote;
					selectedID = id;
				}
			}
		}
		return selectedID;
	}

	private void addLocalImage(Integer cloudID, Image image, double imageSize, Long time) {
		if (imageSize > (this.repository.getAvailableSpace() + this.repository
				.getRemoteSpace())) {
			this.repository.removeRemote(this.strategy);

			while (imageSize > (this.repository.getAvailableSpace())) {
				removeImageWithCriteria(this.ownerID);
			}
		} else {
			int id = getOverQuotaLeastReputationID(cloudID); // id == 0 não tem
																// cota
																// excedente
			while (imageSize > (this.repository.getAvailableSpace()) && id != 0) {
				removeImageWithCriteria(id);
				id = getOverQuotaLeastReputationID(cloudID);
			}
		}
		this.repository.addImage(cloudID, image, time);
	}

	public boolean contains(int imageID) {
		return this.repository.contains(imageID);
	}

	// verifica se o sistema está em contenção e armazena o estado da
	// verificação
	public void verifyContention(int... requestsImagesIDs) {
		this.repository.verifyContention(requestsImagesIDs);
	}

	public int getImageOwnerID(int imageID) {
		return this.repository.getImageOwnerID(imageID);
	}

	public void setImageOwnerID(int fromCloudID, int imageID) {
		this.repository.setImageOwnerID(fromCloudID, imageID);
	}

	public void setImageUtilizationTime(int imageID, Long time) {
		this.repository.setImageInsertionTime(imageID, time);
	}

	public int[] getImages() {
		return this.repository.getImagesIDs();
	}

	public String toString() {
		String result = "";
		for (int id : this.repository.getImagesIDs()) {
			result += id + " ";
		}
		result = result.trim();
		result += "] -- Espaço ocupado = " + (this.repository.getTotalSpace() - this.repository.getAvailableSpace());
		result += " -- Espaço ocioso = " + this.repository.getAvailableSpace();
		result += " -- Espaço ocupado por imagens remotas = " + this.repository.getRemoteSpace();
		result += " -- Imagens locais = " + this.repository.getImagesIDs(ownerID);
		result += " -- Imagens remotas = " + this.repository.remoteImageIDsToString();

		return result;
	}

	public void scoreByImage(int cloudID, int imageID, long score) {
		this.strategy.scoreByImage(imageID, score);
	}

	public long getScoreByImage(int imageID) {
		return this.strategy.getScoreByImage(imageID);
	}

	public void setImageStatus(Integer id, IMAGE_STATUS ready) {
		this.repository.setImageStatus(id, ready);
	}

	public boolean verifySituation(int imageID) {
		return this.repository.isReady(imageID);
	}

}
