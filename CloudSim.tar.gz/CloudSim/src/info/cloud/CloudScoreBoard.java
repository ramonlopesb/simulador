package info.cloud;


public class CloudScoreBoard {

	// from, to, score
	private long[][] byCloud = new long[16][16];
	private static CloudScoreBoard instance;

	private CloudScoreBoard() {
		for (int i = 0; i < byCloud.length; i++) {
			for (int j = 0; j < byCloud.length; j++) {
				byCloud[i][j] = 0L;
			}
		}
	}

	public static CloudScoreBoard getInstance() {
		if (instance == null) {
			instance = new CloudScoreBoard();
		}
		return instance;
	}

	public synchronized void scoreByCloud(int cloudID, int toCloudID, long score) {
		byCloud[cloudID][toCloudID] = byCloud[cloudID][toCloudID] + score;
	}

	/**
	 * Contabilidade dos favores recebidos e prestados por cloudID a toCloudID.
	 * O máximo entre 0 e (favores prestados por toCloudID a cloudID - favores
	 * prestados por cloudID a toCloudID).
	 * 
	 * @param cloudID
	 * @param toCloudID
	 * @return
	 */
	public synchronized long getAccounting(int cloudID, int toCloudID) {
		long received = byCloud[toCloudID][cloudID];
		long provided = byCloud[cloudID][toCloudID];
		return Math.max(0L, received - provided);
	}

	public synchronized double calculateQuote(Integer ownerID, Integer cloudID, double space) {
		double reputation = calculateReputation(ownerID, cloudID);
		return reputation == 0.0 ? 0.0 : reputation * space;
	}

	private double calculateReputation(Integer cloudID, Integer toCloudID) {
		long dividend = CloudScoreBoard.getInstance().getAccounting(cloudID, toCloudID);
		long divisor = 0L;
		for (int i = 1; i < 16; i++) {
			divisor += getAccounting(cloudID, i);
		}
		return (divisor == 0L) ? 0.0 : (1.0 * dividend / divisor);
	}

	public void resetInstance() {
		instance = null;
	}

	public String toString() {
		String result = "[";
		for (int i = 1; i < 16; i++) {
			result += i + " = [";
			for (int j = 1; j < 16; j++) {
				result += j + " = " + byCloud[i][j] + ", ";
			}
			result += "] -- ";
		}
		result += "]";
		return result;
	}

}
