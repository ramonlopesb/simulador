package info.cloud;

import java.util.List;

import info.RequestEvent;

public class CloudRequests {
	
	private int cloudID;
	private List<RequestEvent> requests;
	
	public CloudRequests(int id, List<RequestEvent> r) {
		this.cloudID = id;
		this.requests = r;
	}
	
	public int getCloudID() {
		return this.cloudID;
	}
	
	public List<RequestEvent> getRequests() {
		return this.requests;
	}

}
