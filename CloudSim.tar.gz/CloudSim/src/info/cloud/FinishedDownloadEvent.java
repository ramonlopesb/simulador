package info.cloud;


public class FinishedDownloadEvent {
	
	private int imageID;
	private int cloudID;
	private long time;
	
	public FinishedDownloadEvent(int imageID, int cloudID, long time) {
		this.imageID = imageID;
		this.cloudID = cloudID;
		this.time = time;
	}

	public Integer getID() {
		return this.imageID;
	}
	
	public int getCloudID() {
		return this.cloudID;
	}
	
	public long getTime() {
		return this.time;
	}

}
