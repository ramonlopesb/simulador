package info.cloud;

import info.RequestEvent;

public class ScoreEvent {

	private int cloudID;
	private RequestEvent r;

	public ScoreEvent(int cloudID, RequestEvent r) {
		this.r = r;
		this.cloudID = cloudID;
	}
	
	public RequestEvent getRequest() {
		return this.r;
	}
	
	public int getCloudID() {
		return this.cloudID;
	}

}
