package info;

import java.util.Observable;

public class GlobalClock extends Observable implements Runnable {
	
	private long time;
	private long timeToEnd;
	
	public GlobalClock(long timeToEnd) {
		this.time = 0;
		this.timeToEnd = timeToEnd;
	}
	
	@Override
	public void run() {
		while (time <= timeToEnd) {
			try {
				synchronized (this) {
					this.wait(10);
				}
				setChanged();
				notifyObservers(new Long(++time));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}
