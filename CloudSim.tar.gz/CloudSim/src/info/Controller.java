package info;

import info.cloud.Cloud;
import info.log.InitiationTimeLog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Controller extends Thread {

	private static Controller instance;
	private File workloadFile;
	private Map<Long, Map<Integer, List<Object>>> events;
	private Map<Long, Map<Integer, List<Object>>> additionalEvents;
	private Cloud[] clouds;
	private List<Integer> attendedsRequests;

	private Controller() {
		this.attendedsRequests = new ArrayList<Integer>();
		events = new HashMap<Long, Map<Integer, List<Object>>>();
		additionalEvents = new HashMap<Long, Map<Integer, List<Object>>>();
	}

	public static Controller getInstance() {
		if (instance == null) {
			instance = new Controller();
		}
		return instance;
	}

	public void setClouds(Cloud[] clouds) {
		this.clouds = clouds;
	}

	public void setWorkloadFile(File f) {
		this.workloadFile = f;
	}

	@Override
	public void run() {
		FileInputStream stream;
		try {
			stream = new FileInputStream(workloadFile);
			Scanner sc = new Scanner(stream);
			int delimiter = Integer.valueOf(SystemProperties.getInstance().getPropertyValue("delimiter"));
			int start = 0;
			while (sc.hasNext()) {
				long count = start;
				readNextLines(sc, start, start + delimiter);
				start += delimiter;

				// adiciona os tempos dos eventos e dos eventos adicionais
				List<Long> times = addTimes(new ArrayList<Long>(), events.keySet());

				while (count <= start) {
					Long time = times.get(0);

					Map<Integer, List<Object>> join = new HashMap<Integer, List<Object>>(events.get(time));

					for (Iterator<Integer> cloudIt = join.keySet().iterator(); cloudIt.hasNext();) {
						int cloudID = cloudIt.next();

						// junta as listas de eventos
						List<Object> eventList = new ArrayList<Object>(events.get(time).get(cloudID));
						
//						for (int i = 1; i < clouds.length; i++) {
//							LogWritter.getInstance().write(
//									time + " -- " + "Nuvem " + i + ": " + clouds[i].getCacheSystem().toString());
//						}

						// faz a nuvem de origem responder
						for (Object o : eventList) {
							if (o instanceof RequestEvent) {
								if (!this.attendedsRequests.contains(((RequestEvent) o).getWorkloadID())) {
									InitiationTimeLog.getInstance().write(
											time + " -- [" + ((RequestEvent) o).toString() + "] requisitado pela nuvem " + cloudID + ". ");
									if (((RequestEvent) o).isPending()) {
										clouds[cloudID].answer(o);
									} else {
										((RequestEvent) o).checkPending();
										this.attendedsRequests.add(((RequestEvent) o).getWorkloadID());
									}
								} else {
									((RequestEvent) o).checkPending();
								}
							} else {
								clouds[cloudID].answer(o);
							}
						}

						// se os eventos não foram atendidos pela nuvem origem,
						// tentar em outros de forma aleatória
						for (Iterator<Object> objIt = eventList.iterator(); objIt.hasNext();) {
							Object o = objIt.next();
							if (o instanceof RequestEvent) {
								RequestEvent e = (RequestEvent) o;
								if (e.isPending()) {
									int[] randomCloudIDs = getRandomIDs(clouds.length);
									for (int id: randomCloudIDs) {
										if (clouds[id+1].getID() != e.getFromCloudID()) {
											clouds[id+1].answer(e);
										}
										if (!e.isPending()) {
											this.attendedsRequests.add(e.getWorkloadID());
											break;
										}
									}
									if (e.isPending()) {
										RequestEvent newEvent = new RequestEvent(e);
										e.setStartingTime(time + 1000);
										addRequestEvent(time + 1000, cloudID, newEvent);
									}
								} else {
									this.attendedsRequests.add(e.getWorkloadID());
								}
							}
						}

					}

					events.remove(time);
					times = addTimes(times, events.keySet());
					times.remove(time);
					count = time;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	private List<Long> addTimes(List<Long> list, Set<Long> keySet) {
		for (Long time: keySet) {
			if (!list.contains(time)) {
				list.add(time);
			}
		}
		Collections.sort(list);
		return list;
	}

	public int[] getRandomIDs(int cloudsSize) {
		int[] nums = new int[cloudsSize - 1];

		for (int i = 0; i < nums.length; ++i) {
			nums[i] = i;
		}

		Random randomGenerator = new Random();
		int randomIndex;
		int randomValue;

		for (int i = 0; i < nums.length; ++i) {
			randomIndex = randomGenerator.nextInt(nums.length - 2);

			randomValue = nums[randomIndex];
			nums[randomIndex] = nums[i];
			nums[i] = randomValue;
		}

		return nums;
	}

	private void readNextLines(Scanner sc, int start, int end) {
		while (sc.hasNext() && start < end) {
			String[] split = sc.nextLine().split(" ");
			int requestID = Integer.valueOf(split[0]);
			int workloadID = Integer.valueOf(split[1]);
			int cloudID = Integer.valueOf(split[4]);
			long startTime = Long.valueOf(split[2]);
			long durationTime = Long.valueOf(split[3]);
			int imageID = Integer.valueOf(split[5]);

			Workload w = new Workload(workloadID, cloudID, startTime, durationTime, Integer.valueOf(SystemProperties
					.getInstance().getPropertyValue("image.vcpu")), Integer.valueOf(SystemProperties.getInstance()
					.getPropertyValue("image.ram")), Double.valueOf(SystemProperties.getInstance().getPropertyValue(
					"image.disk")));
			w.setImage(imageID);

			addRequestEvent(startTime, cloudID, new RequestEvent(requestID, w));

			start++;
		}
	}

	public void addRequestEvent(long time, int cloudID, Object event) {
		if (events.get(time) == null) {
			events.put(time, new HashMap<Integer, List<Object>>());
		}
		if (events.get(time).get(cloudID) == null) {
			events.get(time).put(cloudID, new ArrayList<Object>());
		}
		events.get(time).get(cloudID).add(event);
	}

}
