package info.replacement;

import info.RequestEvent;
import info.cloud.ImageScoreBoard;
import info.image.WebImageRepository;

public class LeastProfitable extends ImageScoreBoard implements CacheEvictionStrategyIF {

	@Override
	public void score(int cloudID, RequestEvent r) {
		long score = r.getDurationTime() * WebImageRepository.getInstance().getImage(r.getImageID()).getSize();
		scoreByImage(r.getImageID(), score);
	}

}
