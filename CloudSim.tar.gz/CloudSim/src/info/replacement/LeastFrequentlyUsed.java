package info.replacement;

import info.RequestEvent;
import info.cloud.ImageScoreBoard;


public class LeastFrequentlyUsed extends ImageScoreBoard implements CacheEvictionStrategyIF {

	@Override
	public void score(int cloudID, RequestEvent r) {
		scoreByImage(r.getImageID(), 1);
	}

}
