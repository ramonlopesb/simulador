package info.replacement;

import info.RequestEvent;

public interface CacheEvictionStrategyIF {
	
	void score(int cloudID, RequestEvent r);

}
