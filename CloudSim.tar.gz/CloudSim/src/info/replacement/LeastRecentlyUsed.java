package info.replacement;

import info.RequestEvent;
import info.cloud.ImageScoreBoard;

public class LeastRecentlyUsed extends ImageScoreBoard implements CacheEvictionStrategyIF {
	
	@Override
	public void scoreByImage(int imageID, long score) {
		byImage[imageID] = score;
	}

	@Override
	public void score(int cloudID, RequestEvent r) {
		scoreByImage(r.getFromCloudID(), r.getStartTime());
	}

}
