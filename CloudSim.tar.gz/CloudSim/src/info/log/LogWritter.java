package info.log;

import java.io.IOException;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class LogWritter {
	
	Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	static private FileHandler fileTxt;
	static private SimpleFormatter formatterTxt;

	private static LogWritter instance;
	
	private LogWritter() {
	}

	public static LogWritter getInstance() {
		if (instance == null) {
			instance = new LogWritter();
			try {
				instance.setup();
			} catch (SecurityException | IOException e) {
				e.printStackTrace();
			}
		}
		return instance;
	}

	public void write(String msg) {
		logger.info(msg);
	}

	public void setup() throws SecurityException, IOException {
		logger.setLevel(Level.INFO);
		fileTxt = new FileHandler("Activity_Log.txt");

		// create a TXT formatter
		formatterTxt = new SimpleFormatter();
		fileTxt.setFormatter(formatterTxt);
		logger.addHandler(fileTxt);
	}
}
