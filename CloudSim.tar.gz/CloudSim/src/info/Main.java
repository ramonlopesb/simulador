package info;

import info.cloud.Cloud;
import info.cloud.CloudImageRepository;
import info.cloud.Resources;
import info.filesystem.DeduplicationFileSystem;
import info.filesystem.NoDeduplicationFileSystem;
import info.image.Image;
import info.image.ImagesSize;
import info.image.WebImageRepository;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

import com.google.common.io.Files;

public class Main {

	private static int CLOUDS_SIZE;

	public static void main(String[] args) throws ParserConfigurationException, IOException, JDOMException {
		// Criamos um objeto SAXBuilder
		// para ler o arquivo
		SAXBuilder sb = new SAXBuilder();

		SystemProperties.getInstance().load(new FileInputStream(new File("Properties.properties")));
		CLOUDS_SIZE = Integer.valueOf(SystemProperties.getInstance().getPropertyValue("clouds"));

		Document docImages = sb.build(new File("images.xml"));
		Document docVOs = sb.build(new File("VO.xml"));
		Document docVOsImages = sb.build(new File("VOs_Images.xml"));

		File deduped_images = new File("final_result.txt");

		Map<String, Image> images = readImages(docImages.getRootElement());
		Cloud[] clouds = readVOs(docVOs.getRootElement(), docVOsImages.getRootElement(), images);

		ImagesSize.getInstance().setStrategy(new NoDeduplicationFileSystem());
		// readDedupedImages(deduped_images, images);
		Controller controller = Controller.getInstance();
		controller.setClouds(clouds);
		controller.setWorkloadFile(new File("result_workload.txt"));
		
		controller.start();
	}

	private static void readDedupedImages(File deduped_images, Map<String, Image> images) throws IOException {
		DeduplicationFileSystem deduped_data = new DeduplicationFileSystem();
		List<String> lines = Files.readLines(deduped_images, Charset.defaultCharset());
		for (String line : lines) {
			Map<Integer, Double> info = new HashMap<Integer, Double>();
			String[] imagesNames = line.split(":");
			String[] names = imagesNames[0].split(" ");
			int size = Integer.valueOf(imagesNames[1].trim());
			String imagesIDs = "";
			imagesIDs.trim();
			for (String name : names) {
				info.put(images.get(name).getID(), new Double(size));
			}
			deduped_data.addInformation(info);
			ImagesSize.getInstance().setStrategy(deduped_data);
		}

	}

	private static Map<String, Image> readImages(Element doc) {
		Map<String, Image> images = new HashMap<String, Image>();
		List<Element> nodeImages = doc.getChildren("image");
		for (Element e : nodeImages) {
			Image image = new Image(e.getAttributeValue("name"), e.getAttributeValue("os"),
					e.getAttributeValue("os_version"), Integer.parseInt(e.getAttributeValue("id")), Integer.parseInt(e
							.getAttributeValue("size")));
			images.put(e.getAttributeValue("name"), image);
		}
		return images;
	}

	private static Cloud[] readVOs(Element vos, Element docVOsImages, Map<String, Image> images) {
		Cloud[] clouds = new Cloud[CLOUDS_SIZE + 1];
		List<Element> vosList = vos.getChildren("site");
		for (Element vo : vosList) {
			int cloudID = Integer.parseInt(vo.getAttributeValue("id"));
			String cloudName = vo.getAttributeValue("name");
			Resources resources = new Resources(Integer.parseInt(SystemProperties.getInstance().getPropertyValue(
					"cloud.vcpu")), Integer.parseInt(SystemProperties.getInstance().getPropertyValue("cloud.ram")),
					Double.parseDouble(SystemProperties.getInstance().getPropertyValue("cloud.disk")),
					Integer.parseInt(SystemProperties.getInstance().getPropertyValue("cloud.bandwidth")));
			CloudImageRepository repository = new CloudImageRepository(cloudID, Double.valueOf(SystemProperties
					.getInstance().getPropertyValue("repository.capacity")));
			for (Image img : getCloudImages(docVOsImages, cloudID, images)) {
				if (img != null) {
					repository.addImage(cloudID, img, 0L);
				}
			}
			Cloud cloud = new Cloud(cloudID, cloudName, resources, repository);
			clouds[cloudID] = cloud;
		}
		WebImageRepository.getInstance().setImages(new ArrayList<Image>(images.values()));
		return clouds;
	}

	private static List<Image> getCloudImages(Element docVOsImages, int id, Map<String, Image> images) {
		List<Image> voImages = new ArrayList<Image>();
		List<Element> list = docVOsImages.getChildren("site");
		for (Element s : list) {
			if (Integer.valueOf(s.getAttributeValue("id")) == id) {
				List<Element> imgs = s.getChildren("image");
				for (Element img : imgs) {
					int imageId = Integer.valueOf(img.getText());
					voImages.add(getImageByID(imageId, images));
				}
			}
		}
		return voImages;
	}

	private static Image getImageByID(int imageId, Map<String, Image> images) {
		for (String name : images.keySet()) {
			if (images.get(name).getID() == imageId) {
				return images.get(name);
			}
		}
		return null;
	}

}
