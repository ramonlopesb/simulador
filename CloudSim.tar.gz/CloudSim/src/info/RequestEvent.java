package info;

public class RequestEvent {

	private int requestID;
	private Workload w;
	private boolean pending;

	public RequestEvent(int requestID, Workload workload) {
		this.requestID = requestID;
		this.w = workload;
		this.pending = true;
	}

	public RequestEvent(RequestEvent request) {
		this(request.getRequestID(), new Workload(request.getWorkload()));
		this.setPending(request.isPending());
	}
	
	public void setFromCloudID(int id) {
		this.w.setFromCloudID(id);
	}

	private Workload getWorkload() {
		return this.w;
	}

	public int getRequestID() {
		return this.requestID;
	}
	
	public int getWorkloadID() {
		return this.w.getID();
	}

	public int getVCPUs() {
		return this.w.getVCPUs();
	}

	public int getRam() {
		return this.w.getRam();
	}

	public double getDiskSize() {
		return this.w.getDiskSize();
	}

	public int getImageID() {
		return this.w.getImageID();
	}

	public synchronized void setPending(boolean situation) {
		this.pending = situation;
	}

	public synchronized boolean checkPending() {
		if (this.pending) {
			this.pending = false;
			return true;
		}
		return false;
	}

	public long getDurationTime() {
		return this.w.getDurationTime();
	}

	public long getStartTime() {
		return this.w.getStartingTime();
	}

	public int getFromCloudID() {
		return this.w.getFromCloudID();
	}

	public void setStartingTime(long time) {
		this.w.setStartingTime(time);
	}

	@Override
	public String toString() {
		String result = "";
		result += "Pedido - ID: " + this.getWorkloadID() + ", Início: " + this.getStartTime() + ", Fim: "
				+ (this.getStartTime() + this.getDurationTime()) + ", Imagem: " + this.getImageID()
				+ ", Nuvem Origem: " + this.getFromCloudID();
		return result;
	}

	public boolean isPending() {
		return this.pending;
	}

}
