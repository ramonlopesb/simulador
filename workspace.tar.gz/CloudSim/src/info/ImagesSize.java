package info;


public class ImagesSize {

	private static ImagesSize instance;
	private FileSystemIF fs;

	private ImagesSize() {
	}

	public static ImagesSize getInstance() {
		if (instance == null) {
			instance = new ImagesSize();
		}
		return instance;
	}
	
	public void setStrategy(FileSystemIF fs) {
		this.fs = fs;
	}
	
	public double getSizeOf(int[] storedIDs, int... toStore) {
		return fs.getSizeOf(storedIDs, toStore);
	}
	
	public double getSizeOf(int[] storedIDs) {
		return fs.getSizeOf(storedIDs);
	}

}
