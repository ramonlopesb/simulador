package info.cloud;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;

import com.google.common.primitives.Ints;

import info.GlobalClock;
import info.LogWritter;
import info.Request;
import info.Resources;
import info.VirtualMachine;
import info.image.WebImageRepository;

;

public class Cloud implements Observer {

	private static final int REQUEST_ID = 0;
	private static final int IMAGE_ID = 1;
	private static final int STARTING_TIME = 2;
	private static final int ENDING_TIME = 3;
	private static final int DURATION_TIME = 4;

	private int id;
	private String name;
	private Resources resources;
	private CloudScoreBoard scoreBoard = CloudScoreBoard.getInstance();

	private Long time;

	private List<Request> completedRequests;

	// <pedido, tempo>
	private Map<Request, Long> pendingRequests;

	// <id da imagem, <tempo, id da cloud que requisitou>>
	private Map<Integer, Object[]> imagesToDownload;

	// <id da imagem, vm>
	private Map<Integer, Map<Long, List<Request>>> imageThreads;

	// o cache system é responsável pelo repositório de imagens
	private CacheSystem cacheSystem;

	public Cloud(int id, String name, Resources resources, CloudImageRepository repository) {
		this.id = id;
		this.name = name;
		this.resources = resources;
		this.cacheSystem = new CacheSystem(id, repository);
		this.completedRequests = new ArrayList<Request>();
		this.pendingRequests = new HashMap<Request, Long>();
		this.imagesToDownload = new HashMap<Integer, Object[]>();
		this.imageThreads = new HashMap<Integer, Map<Long, List<Request>>>();
	}

	public int getID() {
		return this.id;
	}

	public String getCloudName() {
		return this.name;
	}

	public CacheSystem getCacheSystem() {
		return cacheSystem;
	}

	public synchronized void answer(List<Request> requests) {
		for (Request r : requests) {
			this.cacheSystem.verifyContention(getRequestsImagesIDs(requests));
			if (this.resources.canAnswerRequest(r)) {
				if (this.cacheSystem.contains(r.getImageID())) {
					// se a requisição ainda está pendente, atendê-la
					if (r.isPending()) {
						r.setPending(false);
						resources.allocate(r.getVCPUs(), r.getRam(), r.getDiskSize());

						// pega o dono atual da imagem
						int imageOwnerID = this.cacheSystem.getImageOwnerID(r.getImageID());

						if (imageThreads.get(r.getImageID()) != null) {
							boolean hasOneAlive = false;
							for (Long vmEndTime : imageThreads.get(r.getImageID()).keySet()) {
								if (vmEndTime < time) {
									hasOneAlive = true;
									break;
								}
							}

							// se não tem mais donos, adiciona
							if (!hasOneAlive) {
								if (r.getFromCloudID() != imageOwnerID) {
									this.cacheSystem.setImageOwnerID(r.getFromCloudID(), r.getImageID());
								}
							}
						}
						long endTime = r.getStartTime() + r.getDurationTime();
						LogWritter.getInstance().write(
								time + " - " + "Nuvem: " + this.id + ": Iniciando a VM da imagem " + r.getImageID()
										+ " do pedido " + r.getRequestID() + " para terminar em " + endTime);
						if (imageThreads.get(r.getImageID()) == null) {
							imageThreads.put(r.getImageID(), new HashMap<Long, List<Request>>());
						}
						if (imageThreads.get(r.getImageID()).get(endTime) == null) {
							imageThreads.get(r.getImageID()).put(endTime, new ArrayList<Request>());
						}
						imageThreads.get(r.getImageID()).get(endTime).add(r);
						this.cacheSystem.setImageUtilizationTime(r.getImageID(), time);
					}
				} else {
					long downloadTime = r.getStartTime() + resources.timeToDownload(r.getImageID());
					// agendar o pedido para após o tempo de download
					LogWritter.getInstance().write(
							time + " - " + "Nuvem: " + this.id + ": Adiando o pedido " + r.getRequestID()
									+ " para o tempo " + downloadTime + " por falta de imagem.");
					this.pendingRequests.put(r, downloadTime);
					if (this.imagesToDownload.get(r.getImageID()) == null) {
						this.imagesToDownload.put(r.getImageID(), new Object[] { downloadTime, r.getFromCloudID() });
					}
				}
			} else {
				// tentar novamente em 10s
				LogWritter.getInstance().write(
						time + " - " + "Nuvem: " + this.id + ": Adiando o pedido " + r.getRequestID()
								+ " para o tempo " + r.getStartTime() + " por falta de recursos.");
				this.pendingRequests.put(r, r.getStartTime() + 10);
			}
		}
	}

	private int[] getRequestsImagesIDs(List<Request> requests) {
		Set<Integer> a = new HashSet<Integer>();
		for (Request r : requests) {
			a.add(r.getImageID());
		}
		return Ints.toArray(a);
	}

	public void score(Request r) {
		if (r.getFromCloudID() != this.id) {
			long score = r.getDurationTime() * WebImageRepository.getInstance().getImage(r.getImageID()).getSize();
			LogWritter.getInstance().write(
					time + " - " + "Nuvem: " + this.id + ": Pontuando a quantidade de " + score
							+ " por ter iniciado uma VM da imagem " + r.getImageID() + " à nuvem " + r.getFromCloudID()
							+ " referente ao pedido " + r.getRequestID());
			this.completedRequests.add(r);
			this.resources.deallocate(r.getVCPUs(), r.getRam(), r.getDiskSize());

			// pontua
			scoreBoard.scoreByCloud(this.id, r.getFromCloudID(), score);
		}
		scoreBoard.scoreByImage(this.id, r.getImageID(), r.getDurationTime());
		this.pendingRequests.remove(r);
	}

	@Override
	public void update(Observable o, final Object arg) {
		if (arg instanceof Long) { // atualizando uma imagem que está
									// sendo baixada
			time = (Long) arg;
			// images com download completo
			List<Integer> removedIDs = new ArrayList<Integer>();
			for (Integer imageID : imagesToDownload.keySet()) {
				Object[] data = imagesToDownload.get(imageID);
				if ((Long) data[0] == time) {
					LogWritter.getInstance().write(
							time + " - Adicionando a imagem " + imageID + " na nuvem " + this.id + " para a nuvem "
									+ data[1]);
					cacheSystem.add((Integer) data[1], WebImageRepository.getInstance().getImage(imageID), time);
					removedIDs.add(imageID);
				}
			}
			// remove imagens já adicionadas
			for (Integer id : removedIDs) {
				imagesToDownload.remove(id);
			}

			// pendentes
			if (!pendingRequests.isEmpty()) {
				List<Request> requests = new ArrayList<Request>();
				for (Request r : pendingRequests.keySet()) {
					if (pendingRequests.get(r) == time) {
						if (r.isPending()) {
							r.setStartingTime(time);
							requests.add(r);
						}
					}
				}
				answer(requests);
			}

			// vms com tempo final
			for (Integer imageID : imageThreads.keySet()) {
				if (imageThreads.get(imageID).get(time) != null) {
					for (Request r : imageThreads.get(imageID).get(time)) {
						score(r);
					}
				}
			}

		} else if (arg instanceof List) { // atualizando novos pedidos
			final List<Request> cr = (List<Request>) arg;
			answer(cr);
		}
	}

}
