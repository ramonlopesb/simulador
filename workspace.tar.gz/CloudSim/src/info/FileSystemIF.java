package info;

public interface FileSystemIF {
	
	public double getSizeOf(int[] storedIDs, int... toStore);
	
	public double getSizeOf(int[] storedIDs);

}
