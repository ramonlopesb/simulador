package info;

import info.image.WebImageRepository;

public class NoDeduplicationFileSystem implements FileSystemIF {

	@Override
	public double getSizeOf(int[] storedIDs, int... toStore) {
		return getSizeOf(storedIDs) + getSizeOf(toStore);
	}

	@Override
	public double getSizeOf(int[] storedIDs) {
		double size = 0.0;
		for (int id: storedIDs) {
			size += WebImageRepository.getInstance().getImage(id).getSize();
		}
		return size;
	}

}
