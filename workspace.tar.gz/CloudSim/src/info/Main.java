package info;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.xml.parsers.ParserConfigurationException;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

import com.google.common.io.Files;

import info.cloud.Cloud;
import info.cloud.CloudImageRepository;
import info.image.Image;
import info.image.WebImageRepository;

public class Main {

	public static void main(String[] args) throws ParserConfigurationException, IOException, JDOMException {
		// Criamos um objeto SAXBuilder
		// para ler o arquivo
		SAXBuilder sb = new SAXBuilder();

		SystemProperties.getInstance().load(new FileInputStream(new File("Properties.properties")));

		Document docImages = sb.build(new File("images.xml"));
		Document docVOs = sb.build(new File("VO.xml"));
		Document docVOsImages = sb.build(new File("VOs_Images.xml"));

		File deduped_images = new File("final_result.txt");

		Map<String, Image> images = readImages(docImages.getRootElement());
		List<Cloud> clouds = readVOs(docVOs.getRootElement(), docVOsImages.getRootElement(), images);
		Map<Long, List<Workload>> workloads = readWorkload(clouds);

		ImagesSize.getInstance().setStrategy(new NoDeduplicationFileSystem());
		// readDedupedImages(deduped_images, images);
		Controller controller = new Controller(workloads);

		GlobalClock gc = GlobalClock.getInstance();

		gc.addObserver(controller);
		for (Cloud c : clouds) {
			gc.addObserver(c);
			controller.addObserver(c);
		}
		gc.run();
	}

	private static void readDedupedImages(File deduped_images, Map<String, Image> images) throws IOException {
		DeduplicationFileSystem deduped_data = new DeduplicationFileSystem();
		List<String> lines = Files.readLines(deduped_images, Charset.defaultCharset());
		for (String line : lines) {
			Map<Integer, Double> info = new HashMap<Integer, Double>();
			String[] imagesNames = line.split(":");
			String[] names = imagesNames[0].split(" ");
			int size = Integer.valueOf(imagesNames[1].trim());
			String imagesIDs = "";
			imagesIDs.trim();
			for (String name : names) {
				info.put(images.get(name).getID(), new Double(size));
			}
			deduped_data.addInformation(info);
			ImagesSize.getInstance().setStrategy(deduped_data);
		}

	}

	private static Map<Long, List<Workload>> readWorkload(List<Cloud> clouds) throws IOException {
		List<String> lines = Files.readLines(new File("result_workload.txt"), Charset.defaultCharset());
		Map<Long, Map<Integer, Map<Integer, List<Workload>>>> byTime = new HashMap<Long, Map<Integer, Map<Integer, List<Workload>>>>();
		Map<Long, List<Workload>> workloads = new HashMap<Long, List<Workload>>();
		for (String line : lines) {
			String[] split = line.split(" ");
			int requestID = Integer.valueOf(split[0]);
			int cloudID = Integer.valueOf(split[3]);
			long time = Long.valueOf(split[1]);
			int userID = Integer.valueOf(split[4]);
			// 1 é a posicao do tempo de inicio do pedido, 2 é o tempo de
			// execucao, 3 é a nuvem
			if (byTime.get(time) == null) {
				byTime.put(time, new HashMap<Integer, Map<Integer, List<Workload>>>());
			}

			if (byTime.get(time).get(cloudID) == null) {
				byTime.get(time).put(cloudID, new HashMap<Integer, List<Workload>>());
			}

			if (byTime.get(time).get(cloudID).get(userID) == null) {
				byTime.get(time).get(cloudID).put(userID, new ArrayList<Workload>());
			}

			byTime.get(time)
					.get(cloudID)
					.get(userID)
					.add(new Workload(requestID, cloudID, time, Long.valueOf(split[2]), Integer
							.valueOf(SystemProperties.getInstance().getPropertyValue("image.vcpu")), Integer
							.valueOf(SystemProperties.getInstance().getPropertyValue("image.ram")), Integer
							.valueOf(SystemProperties.getInstance().getPropertyValue("image.disk"))));
		}

		// seta as imagens por jobs (composição de tarefas)
		for (Long time : byTime.keySet()) {
			if (workloads.get(time) == null) {
				workloads.put(time, new ArrayList<Workload>());
			}
			Map<Integer, Map<Integer, List<Workload>>> byCloud = byTime.get(time);
			for (Integer cloudID : byCloud.keySet()) {
				int cloudImagesNumber = 0;
				for (Cloud c : clouds) {
					if (c.getID() == cloudID) {
						cloudImagesNumber = c.getCacheSystem().getImages().length;
						break;
					}
				}
				int randomImageID = 1 + new Random().nextInt(cloudImagesNumber);
				Map<Integer, List<Workload>> byUser = byCloud.get(cloudID);
				for (Integer userID: byUser.keySet()) {
					for (Workload w: byUser.get(userID)) {
						w.setImage(randomImageID);
						workloads.get(time).add(w);
					}
				}
			}
		}
		
		return workloads;
	}

	private static Map<String, Image> readImages(Element doc) {
		Map<String, Image> images = new HashMap<String, Image>();
		List<Element> nodeImages = doc.getChildren("image");
		for (Element e : nodeImages) {
			Image image = new Image(e.getAttributeValue("name"), e.getAttributeValue("os"),
					e.getAttributeValue("os_version"), Integer.parseInt(e.getAttributeValue("id")), Integer.parseInt(e
							.getAttributeValue("size")));
			images.put(e.getAttributeValue("name"), image);
		}
		return images;
	}

	private static List<Cloud> readVOs(Element vos, Element docVOsImages, Map<String, Image> images) {
		List<Cloud> clouds = new ArrayList<Cloud>();
		List<Element> vosList = vos.getChildren("site");
		for (Element vo : vosList) {
			int cloudID = Integer.parseInt(vo.getAttributeValue("id"));
			String cloudName = vo.getAttributeValue("name");
			Resources resources = new Resources(Integer.parseInt(SystemProperties.getInstance().getPropertyValue(
					"cloud.vcpu")), Integer.parseInt(SystemProperties.getInstance().getPropertyValue("cloud.ram")),
					Double.parseDouble(SystemProperties.getInstance().getPropertyValue("cloud.disk")),
					Integer.parseInt(SystemProperties.getInstance().getPropertyValue("cloud.bandwidth")));
			CloudImageRepository repository = new CloudImageRepository(cloudID, 200.0);
			for (Image img : getCloudImages(docVOsImages, cloudID, images)) {
				if (img != null) {
					repository.addImage(cloudID, img, 0L);
				}
			}
			Cloud cloud = new Cloud(cloudID, cloudName, resources, repository);
			clouds.add(cloud);
		}
		WebImageRepository.getInstance().setImages(new ArrayList<Image>(images.values()));
		return clouds;
	}

	private static List<Image> getCloudImages(Element docVOsImages, int id, Map<String, Image> images) {
		List<Image> voImages = new ArrayList<Image>();
		List<Element> list = docVOsImages.getChildren("site");
		for (Element s : list) {
			if (Integer.valueOf(s.getAttributeValue("id")) == id) {
				List<Element> imgs = s.getChildren("image");
				for (Element img : imgs) {
					int imageId = Integer.valueOf(img.getText());
					voImages.add(getImageByID(imageId, images));
				}
			}
		}
		return voImages;
	}

	private static Image getImageByID(int imageId, Map<String, Image> images) {
		for (String name : images.keySet()) {
			if (images.get(name).getID() == imageId) {
				return images.get(name);
			}
		}
		return null;
	}

}
