package test;

import static org.junit.Assert.assertEquals;
import info.ImagesSize;
import info.NoDeduplicationFileSystem;
import info.SystemProperties;
import info.cloud.CloudImageRepository;
import info.image.Image;
import info.image.WebImageRepository;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class CloudImageRepositoryTest {

	CloudImageRepository rep;
	Image image1;
	Image image2;
	Image image3;
	Image image4;

	@Before
	public void setUp() throws FileNotFoundException, IOException {
		SystemProperties.getInstance().load(
				new FileInputStream(new File("/home/ramon/workspace/CloudSim/Properties.properties")));
		rep = new CloudImageRepository(1, 102400.0);
		ImagesSize.getInstance().setStrategy(new NoDeduplicationFileSystem());
		image1 = new Image("", "", "", 1, 25600);
		image2 = new Image("", "", "", 2, 25600);
		image3 = new Image("", "", "", 3, 25600);
		image4 = new Image("", "", "", 4, 25600);

		rep.addImage(1, image1, 1L);
		rep.addImage(1, image2, 2L);
		rep.addImage(2, image3, 3L);
		rep.addImage(3, image4, 4L);
		WebImageRepository.getInstance().setImages(new ArrayList<Image>() {
			{
				add(image1);
				add(image2);
				add(image3);
				add(image4);
			}
		});
	}

	@Test
	public void addImageTest() {
		assertEquals(1, rep.getImagesIDs()[0]);
		assertEquals(2, rep.getImagesIDs()[1]);
		assertEquals(3, rep.getImagesIDs()[2]);
		assertEquals(4, rep.getImagesIDs()[3]);

		// cloud 1
		assertEquals(2, rep.getImagesIDs(1).size());
		assertEquals(new Integer(1), rep.getImagesIDs(1).get(0));
		assertEquals(new Integer(2), rep.getImagesIDs(1).get(1));

		// cloud 2
		assertEquals(1, rep.getImagesIDs(2).size());
		assertEquals(new Integer(3), rep.getImagesIDs(2).get(0));

		// cloud 3
		assertEquals(1, rep.getImagesIDs(3).size());
		assertEquals(new Integer(4), rep.getImagesIDs(3).get(0));
	}

	@Test
	public void getRemoteIDsTest() {
		assertEquals(2, rep.getRemoteImagesIDs().size());
	}

	@Test
	public void getRemoteSpaceTest() {
		assertEquals(51200, rep.getRemoteSpace(), 0.0);
	}
	
	@Test
	public void getExpiredSpaceTest() {
		assertEquals(102400, rep.getExpiredSpace(120), 0.0);
	}

}
